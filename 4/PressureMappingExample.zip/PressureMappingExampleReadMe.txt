I uploaded a simple example that demonstrates mapping between dissimilar meshes and element types.

The zip file contains the macro and jpg output.

You can experiment with three element types (45s, 92s, and 95s) by editing the macro.  Element sizes can be adjusted in the same way.

The macro is based on xansys message 38689 by golee26 RE: Pressure Mapping dated 6/11/2002 .

A cube is built and an irregular element pressure pattern (e.g., pressure is discontinuous at internal nodes) is applied to one face of the cube.  The exact reaction is calculated,

The cube is then remeshed with a different element type resulting in a new mesh pattern.  The first mesh is then mapped onto the second using the *MOP command by one of two methods: element-to-element (centroid-to-centroid) or element-to-node (centroid-to-node) mapping.  Results are written to the output window where you can see the discretization error.

At the bottom of the macro is an example of how to apply the mapped results from the first model onto the second using a TABLe.  The TABLe uses the second model's node numbers (sorted and stored in ascending order) to index into the TABLe.  This results in a very efficient way to map boundary conditions that's fast and uses minimum memory.

I often get external results from other programs in the form of convection coefficients, bulk temperatures, and pressures at XYZ locations.  The data is always continuous as opposed to the pressure field that I imposed in the macro model.  Usually, only a small percentage of the nodes in my FE model actually need to have boundary conditions applied.  As an example, a model with, say, 150,000 nodes might only have 5,000 of them on the surface.  While you can *VMAsk the interior nodes and apply the surface conditions, this invariably results in manipulating much larger arrays than using the TABLe approach.  In any event, I prefer to MAP these BCs from external CFD codes onto my ANSYS model using a TABLe rather than *VMAsking the whole model.

Here are the results I got when I executed this macro on 6.0 and 6.1:

---------- Pressure Mapping Example Results Comparison ---------

                                              * Reaction Force *
 Model    |   ETYPE    |   Mapping Strategy   |  Exact  |  ANSYS
------    |  -------   |  ------------------  |  -----  |  -----

Map From  |  SOLID45   |         N/A          |  2.500  |  2.500

Map To    |  SOLID92   |  Element-To-Element  |  2.500  |  2.489

Map To    |  SOLID92   |  Element-To-Node     |  2.500  |  2.540




I had my tab stops set at 2.  The macro will be easier to read if you set your text editor accordingly.


Bob Weathers
bweathers@trane.com
(608)787-2729
