*******************************************************
MACROS TO CONVERT INSTANTANEOUS THERMAL COEFFICIENT OF EXPANSION INTO SECANT FORM

BILL BULAT
14 November 2001

Note: ANSYS Inc. is not responsible for results obtained by the use of these files.
*******************************************************

Description of files:

1) example03.inp:
Defines 2 single column array parameters:

T is the temperature value array
insalpha is an array containing corresponding values of instantaneous alpha

Temperature data in the T array ranges from -40 to 320 with uniform increment
insalpha(T) = 15e-6 for -40 < T < 140
insalpha(T) = 55e-6 for 140 < T < 320

2) ins_sec5.mac:
Macro file which converts instantaneous alpha data into secant form based on a user specified reference (stress-free) temperature. Useage:

ins_sec5,mat id#,Tref

where,

mat id# is the material number for which the secant TCE data is to be defined

Tref is the "reference" temperature (temperature at which no thermal strain exists)

3) pl_epth.mac, pl_alpha.mac:
Macros to plot curves of temperature dependent thermal strain and the 2 forms (instantaneous and secant) of TCE. Toolbar buttons to invoke these macros are placed on the toolbar when ins_sec5.mac is invoked.

******************************************************
TO RUN THE EXAMPLE:
******************************************************

1) Copy all the files listed above into an empty directory.

2) Start an interactive ANSYS session in the directory.

3) In the ANSYS input window, type:
	/input,example03,inp

This will define temperature and instantaneous alpha arrays. A plot will be produced showing the variation of instantaneous alpha with temperature.

4) In the ANSYS input window, type:
	ins_sec5,1,-40


Secant values of alpha will be calculated cooresponding to a refernce temperature of -40. Temperature dependent plots of both forms of alpha will be displayed. Toolbar buttons will be produced which will create plots of the 2 forms of alpha or the temperature dependent thermal strain.

Try other reference temperatures by typing the following in the ANSYS input window:

	ins_sec5,1,0
	ins_sec5,1,100
	ins_sec5,1,120
	ins_sec5,1,140
	ins_sec5,1,200
	ins_sec5,1,320