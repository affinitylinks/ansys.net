function [return_var] = varread(name)
% VARREADP Reads variable output from ansys
%    VARREADP(name) where name is the name of the variable
%    in the file name.varp as formatted by ansys macros
%    varreadp.mac and varwritep.mac
%
%    Returns [variable,number_index] in long format
%    (i.e. scattered)
%
%    Non-vector input results in an error.

% open file: error if not found
[fid,message] = fopen([name,'.varp'],'r');
if (fid < 0)
   error(message);
end

% get dimensions
var_dim = fscanf(fid,'%f',3);

% read in num vector
num = fscanf(fid,'%f',var_dim(1));

% read in rest of file
var = reshape(fscanf(fid,'%f'),var_dim(1),var_dim(2),var_dim(3));

% scatter
count = var_dim(1);
max   = num(count);
return_var = zeros(max,var_dim(2),var_dim(3));
for ii = 1:count
  return_var(num(ii),:,:)=var(ii,:,:);
end

% close file
fclose(fid);
