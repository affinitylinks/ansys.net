function return_var = varread(name)
% VARREAD Reads variable output from ansys
%    VARREAD(name) where name is the name of the variable
%    in the file name.var as formatted by ansys macros
%    varread.mac and varwrite.mac
%    Non-vector input results in an error.

% open file: error if not found
[fid,message] = fopen([name,'.var'],'r');
if (fid < 0)
   error(message);
end

% get dimensions
var_dim = fscanf(fid,'%f',3);

% read in rest of file
return_var = reshape(fscanf(fid,'%f'),var_dim(1),var_dim(2),var_dim(3));

% close file
fclose(fid);
