function varwrite(name)
% VARWRITE Writes variable output to ansys
%    VARWRITE(name) where name is the name of the variable
%    in the file name.var to be written for reading by
%    varread.mac and varwrite.mac

% open file: error if not found
filename=inputname(1);

[fid,message] = fopen([filename,'.var'],'w');
if (fid < 0)
   error(message);
end

% check for dimensions
switch ndims(name)
   case {1},
      dims=size(name);dims(2)=1;dims(3)=1;
   case {2}, 
      dims=size(name);dims(3)=1;
   case {3},
      dims=size(name);
   otherwise,
      error('Only dimensions 1,2 or 3')
end
   
fprintf(fid,'%20.10e%20.10e%20.10e\n',dims);
fprintf(fid,'%20.10e\n',name);
fclose(fid);
