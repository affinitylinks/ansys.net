function return_var = varreadcp(name)
% VARREAD Reads variable output from ansys in complex form
%    VARREAD(name) where name is the name of the variable
%    in the file name.var as formatted by ansys macros
%    varread.mac and varwrite.mac. The second dimension is
%    assumed to be of dimension 2 with dim 1 = real, 
%    dim 2 = complex. Variable is returned squeezed.
%    Non-vector input results in an error.

var = varreadp(name);

var_dims = size(var);

if (var_dims(2) ~= 2)
   error('2nd dimension must equal 2: [Real, Imag]');
end

% read in rest of file
return_var = squeeze(var(:,1,:)+i*var(:,2,:));
