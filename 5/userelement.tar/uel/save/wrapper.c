#include <GL/gl.h>

void glPolygonOffsetEXT(float factor, float bias) {
glPolygonOffset(factor, bias);
}
