#include <fpu_control.h>

/**********************************************************************/
void enable_fp_exceptions_(void)
{
  unsigned long fpucw;

  _FPU_GETCW(fpucw);
  fpucw &= ~_FPU_MASK_IM & ~_FPU_MASK_ZM & ~_FPU_MASK_OM;
  _FPU_SETCW(fpucw);
}

/**********************************************************************/
void disable_fp_exceptions_(void)
{
  unsigned long fpucw;

  _FPU_GETCW(fpucw);
  fpucw |= _FPU_MASK_IM | _FPU_MASK_ZM | _FPU_MASK_OM;
  _FPU_SETCW(fpucw);
}

/**********************************************************************/
