rm file*
ansys110 -b -i material1.inp -o material1.out
mv file.parm material1.parm

rm file.*
ansys110 -b -i material2.inp -o material2.out
mv file.parm material2.parm

#rm file.*
#ansys110 -b -i material3.inp -o material3.out
#mv file.parm material3.parm

#rm file.*
#ansys110 -b -i material4.inp -o material4.out
#mv file.parm material4.parm

ansys110 -b -i material_plot.inp -o file.out
