    This disk contains information about using TCL/TK for developing
ANSYS custom applications.  In this directory you will find the
powerpoint presentation tcl.ppt which gives a brief description of
the tcl facilities available in ANSYS.  Included are the 5.5 and
5.6 versions of multipro55.tk and multiprompt.tk

     There are two subdirectories.  The required files in each subdirectory
  are shown in decklist.

     shaft.dir
       This contains the files for the demonstration of a simple
     ANSYS custom application.  It is an analysis of the fillet stresses
     in a stepped shaft under an axial load.  To see this demonstration,
     enter ANSYS in this subdirectory and enter the command "shaftrun".
     This should work in both 5.5 and 5.6.

     parablock.dir
       This directory contains an example using Tcl/Tk to create a
     custom dialog including ANSYS graphics as a background and 
     positional input fields for parameter entry.  To see this 
     demonstartion enter ANSYS in this subdirectory and enter the
     command "parablock".  This should work in both 5.5 and 5.6.

John Swanson
